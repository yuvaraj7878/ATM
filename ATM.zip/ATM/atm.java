import java.util.*;
class Main{
    int de=10000;
    HashMap<String,Integer> transaction =new HashMap<>();
    int i=1;
 public void checkbalance(){
    
    System.out.println("current Balance="+de);
    
 }

 public void withdraw(int amount){
    if(de<amount){
        
        System.out.println("**Check The Bank Balance**");
        
    }
    else{
    de-=amount;
   
    System.out.println("**Sucessfully depited**");
    
    String j=String.valueOf(i);
    String deposite=j+".Deposite";
    transaction.put(deposite,amount);
    i++;
    }
 }
 public void deposite(int amount)
 {
    
    de+=amount;
   
    System.out.println("**Sucessfully deposited**");
    
    String k=String.valueOf(i);
    String credit=k+".Credited"; 
    transaction.put(credit,amount);
}
public void display(){
    System.out.println("-------------------------------------");
 for(Map.Entry<String,Integer> entry: transaction.entrySet()){
    System.out.println("|\tType =" + entry.getKey()+"\t|"+"\tMoney ="+entry.getValue()+"\t|");
    System.out.println("-------------------------------------");
 }
}
public class atm{
public static void main(String[] args) {
    Scanner input=new Scanner(System.in);
    HashMap<Integer,Integer> insert=new HashMap<>();
    insert.put(2088,3224);
    insert.put(2003,3030);
        Main main=new Main();
        
        
    int i=1;
    while(i<=1)  { 
       
        System.out.println("|Enter the Atm pin number:|");
        
        int pin=input.nextInt();
        if(insert.containsKey(pin)){
        
        System.out.println("Enter the option:");
        
       
        System.out.println("1.balance inquiry,2.cash withdrawel,3.cash deposite,4.pin change,5.transaction history,6.exit");
        
        int option=input.nextInt();
        switch (option) {
            case 1:
                main.checkbalance();
                break;
            case 2:
                 System.out.println("Enter the amount:");
                 int wamount=input.nextInt();
                 main.withdraw(wamount);
                break;
            case 3:
                System.out.println("Enter the amount:");
                int damount=input.nextInt();
                main.deposite(damount);
                break;    
            case 4:
                System.out.println("Enter the Change pin:");
                int changepin=input.nextInt();
                int value=insert.get(pin);
                insert.put(changepin,value);
                System.out.println("**Sucessfully changed**");
                break;    
            case 5:
                System.out.println("Transaction History:");
                main.display();
                break; 
            case 6:
                break; 
            default:
            System.out.println("**Enter the valid option**");
                break;
        }
    }
 }
}
}
}
